package com.centrabiz.payment.model;

import java.math.BigDecimal;

public class PaymentMethod {
    public String id;
    public int discount;
    public BigDecimal limit;
}
